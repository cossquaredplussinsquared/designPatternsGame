package loyal.entities;

public abstract class GoodGuys extends PlayingCharacter {
	// Implement as you see fit but look to the PlayingCharacter class for comments and code that is inherited
	// NOTE: STATS ARE STORED IN THE STATE CLASS SO WE CAN EASILY PASS IT AROUND.
	@Override
	public void Interaction(PlayingCharacter sources, PlayingCharacter[] targets) {
		// TODO Auto-generated method stub

	}

}
