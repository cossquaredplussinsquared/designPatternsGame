package loyal.entities;

public interface Interactable
{
	public void Interaction(PlayingCharacter sources, PlayingCharacter[] targets);
}
