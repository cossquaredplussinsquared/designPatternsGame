package loyal.entities;

public abstract class CharacterAction implements Comparable {

	@Override
	public int compareTo(Object arg0){
		return 0;
	};

}
