package loyal.Battle;

public class Battle {

}
